# Document Q&A RAG Assistant

A Retrieval-Augmented Generation assistant that answers questions from uploaded PDFs.

## Features
- PDF upload
- Text chunking + embeddings
- Vector retrieval using ChromaDB
- LLM answer generation

## Run
pip install -r requirements.txt
streamlit run app.py

## Env Variable
export GROQ_API_KEY=your_key_here
